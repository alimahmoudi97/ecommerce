function page() {
  return <div className="text-3xl">ثبت نام</div>;
}
export default page;
