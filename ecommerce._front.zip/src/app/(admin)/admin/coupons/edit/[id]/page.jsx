function page() {
  return <div>این صفحه در حال ساخت است .از شکیبایی شما سپاسگزارم</div>;
}
export default page;
