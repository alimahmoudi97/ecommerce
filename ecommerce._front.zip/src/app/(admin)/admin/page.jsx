function page() {
  return <div>admin page</div>;
}
export default page;
